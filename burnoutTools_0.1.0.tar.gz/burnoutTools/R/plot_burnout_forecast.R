#' Plot burnout forecast
#'
#' This updated version shows Burnout Risk, Task Load, and Fatigue together
#'
#' @param df Data frame returned by simulate_burnout()
#' @return A ggplot line chart showing how workload, stress, and fatigue evolve.
#' @export
plot_burnout_forecast <- function(df) {
  # Reshape data for ggplot (long format for multiple lines)
  df_long <- tidyr::pivot_longer(df, cols = c("BurnoutRisk", "AvgPendingTasks", "Fatigue"))

  # Create line plot with color-coded metrics
  ggplot2::ggplot(df_long, ggplot2::aes(x = Day, y = value, color = name)) +
    ggplot2::geom_line(size = 1.2) +
    ggplot2::scale_color_manual(values = c(
      "BurnoutRisk" = "firebrick",      # red = risk
      "AvgPendingTasks" = "steelblue",  # blue = backlog
      "Fatigue" = "darkorange"          # orange = cumulative exhaustion
    )) +
    ggplot2::labs(
      title = "Burnout Simulation Forecast",
      subtitle = "Risk (red), Task Load (blue), Fatigue (orange)",
      y = "Level",
      color = "Metric"
    ) +
    ggplot2::theme_minimal()
}
