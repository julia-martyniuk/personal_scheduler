#' Simulate burnout risk over time with dynamic workload
#'
#' This improved version includes new task inflow and productivity fatigue.
#'
#' @param n_tasks Integer. Initial pending tasks at Day 0.
#' @param p Numeric. Base productivity (completion probability, 0 to 1).
#' @param threshold Integer. Task count where burnout risk increases.
#' @param days Integer. Simulation horizon (days).
#' @param reps Integer. Number of repetitions for averaging.
#' @param task_arrival_rate Numeric. Average number of new tasks per day (Poisson).
#' @param seed Integer. Random seed for reproducibility.
#'
#' @return Data frame with BurnoutRisk, AvgPendingTasks, Fatigue per day.
#' @export
simulate_burnout <- function(n_tasks, p, threshold = 3, days = 30, reps = 1000, task_arrival_rate = 0.5, seed = 123) {
  stopifnot(
    n_tasks >= 0,
    p >= 0, p <= 1,
    threshold >= 0,
    days > 0,
    reps > 0,
    task_arrival_rate >= 0
  )

  set.seed(seed)

  # Call the C++ simulation engine with new parameter
  simulate_burnout_cpp(n_tasks, p, threshold, days, reps, task_arrival_rate)
}
