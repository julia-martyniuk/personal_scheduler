#include <Rcpp.h>
using namespace Rcpp;

// [[Rcpp::export]]
DataFrame simulate_burnout_cpp(int n_tasks, double p, int threshold, int days, int reps, double task_arrival_rate = 0.5) {
  // Output vectors: burn risk, backlog, fatigue, and tracking overload days
  std::vector<double> risk(days, 0.0);
  std::vector<double> avg_pending(days, 0.0);
  std::vector<double> fatigue(days, 0.0);
  std::vector<int> over_threshold_count(days, 0);

  // R uses this to manage randomness consistently
  Rcpp::RNGScope rngScope;

  for (int r = 0; r < reps; ++r) {
    int pending = n_tasks;
    double productivity = p;

    for (int d = 0; d < days; ++d) {
      // Simulate how many new tasks arrive today (Poisson-distributed)
      int new_tasks = R::rpois(task_arrival_rate);
      pending += new_tasks;

      // If previous day had high overload, reduce productivity slightly (fatigue)
      if (d > 0 && over_threshold_count[d - 1] > 0) {
        productivity *= 0.98;  // 2% decay
      }

      // Keep productivity within reasonable bounds
      productivity = std::max(0.1, std::min(productivity, 1.0));

      // Simulate how many tasks are completed today (Binomial draw)
      int completed = R::rbinom(pending, productivity);
      pending = std::max(0, pending - completed);

      avg_pending[d] += pending;

      // Burnout risk: soft logistic model, higher when pending >> threshold
      double risk_today = 1.0 / (1.0 + exp(-0.8 * (pending - threshold)));
      risk[d] += risk_today;

      // Fatigue increases when productivity drops
      fatigue[d] += (1.0 - productivity);

      // Count how many days the threshold was exceeded
      if (pending > threshold) over_threshold_count[d]++;
    }
  }

  // Average all simulation results across repetitions
  for (int d = 0; d < days; ++d) {
    risk[d] /= reps;
    avg_pending[d] /= reps;
    fatigue[d] /= reps;
  }

  // Return results as an R dataframe
  return DataFrame::create(
    Named("Day") = seq(1, days),
    Named("BurnoutRisk") = risk,
    Named("AvgPendingTasks") = avg_pending,
    Named("Fatigue") = fatigue
  );
}
